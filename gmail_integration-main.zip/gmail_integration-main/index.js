"use strict";
const Factory = require('./gmail/Factory.js');

module.exports = Factory;