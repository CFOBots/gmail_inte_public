"use strict";
const Abstract = require('./Abstract');

module.exports = class Email extends Abstract {

    constructor(settings) {
        super(settings);
        this.responsePropertyName = "messages";
    }

    async getMessage() {

        if(!this.message_id){
            return false;
        }

        let body = this.initBody();

        body.id = this.message_id;
        let response = await this.apiCall("users.messages.get", body);

        if(!response || response.error){
            return false;
        }

        return response;
    }

    async modify(callParameters) {
        return await this.apiCall("users.messages.modify", callParameters);
    }

    async addLabel(label) {
        if (!label || !this.message_id) {
            return false;
        }

        let body = this.initBody();
        body.id = this.message_id;
        body.resource = {
            "addLabelIds": [
                label
            ]
        };
        let response = this.modify(body);

        if (response.id) {
            return true;
        }
        return false;
    }

    async removeLabel(label) {
        if (!label || !this.message_id) {
            return false;
        }

        let body = this.initBody();
        body.id = this.message_id;
        body.resource = {
            "removeLabelIds": [
                label
            ]
        };
        let response = this.modify(body);

        if (response.id) {
            return true;
        }
        return false;
    }

    async replaceLabel(add, remove) {
        if (!add || !remove || !this.message_id) {
            return false;
        }

        let body = this.initBody();
        body.id = this.message_id;

        body.resource = {
            "addLabelIds": [
                add
            ],
            "removeLabelIds": [
                remove
            ]
        };

        let response = this.modify(body);

        if (response.id) {
            return true;
        }
        return false;
    }

    async getAttachment(attach_id) {
        if(!attach_id){
            return false;
        }

        let body = this.initBody();
        body.id = attach_id;
        body.messageId = this.message_id;

        let response = await this.apiCall("users.messages.attachments.get", body);

        if(!response || response.error){
            return false
        }

        return response.data;
    }

    async getMessageWithAttachments(){
        let message = await this.getMessage(this.message_id);
        let attachments = await this.getAttachments(message);

        return {message: message, attachments: attachments}
    }

    async getAttachments(message) {

        if(!message || (message && message.payload && !message.payload.parts) || !message.payload.parts.length){
            return false;
        }

        var attachments = {};
        var parts = message.payload.parts;

        for (var i = 0; i < parts.length; i++) {

            var part = parts[i];

            if (part.filename && part.filename.length > 0) {

                var attach = await this.getAttachment(part.body.attachmentId, message.id);

                if(attach){
                    attachments[part.filename] = attach;
                }
                else{
                    //TODO: log not attachment found (?)
                }
            }
        }


        return attachments;
    }

};