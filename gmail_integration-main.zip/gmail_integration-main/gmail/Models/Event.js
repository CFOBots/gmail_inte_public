"use strict";
const Abstract = require('./Abstract');

module.exports = class Event extends Abstract {

    constructor(settings){
        super(settings);
    }
};