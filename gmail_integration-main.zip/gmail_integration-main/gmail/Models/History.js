"use strict";
const Abstract = require('./Abstract');

module.exports = class History extends Abstract {

    constructor(settings) {
        super(settings);
        this.responsePropertyName = "history";
    }

    async getHistoryListOfMessagesAdded(startHistoryId) {

        let body = this.initBody();
        body.startHistoryId = startHistoryId;
        body.labelId = ["INBOX"];
        body.historyTypes = 'messageAdded';

        let response = await this.apiCall("users.history.list", body);

        return response;
    }
};