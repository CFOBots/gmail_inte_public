"use strict";
const Abstract = require('./Abstract');

module.exports = class User extends Abstract {

    constructor(settings) {
        super(settings);
    }

    async getProfile(callParameters = {userId: 'me'}) {

        return await this.apiCall("users.getProfile", callParameters);
    }

    async watchEmail(topic) {
        if(!topic){
            return false;
        }
        let body = this.initBody();
        body.resource = {topicName: topic, labelIds: ["INBOX"]};
        return await this.apiCall("users.watch", body);
    }

    // https://developers.google.com/gmail/api/guides/push#create_a_topic
    async stopWatch(topic) {
        if(!topic){
            return false;
        }
        let body = this.initBody();
        body.resource = {topicName: topic};
        return await this.apiCall("users.stop", body);
    }

    async createAccount(account_data) {
        let body = {
            "resource": {
                "name": {
                    "familyName": account_data.familyName,
                    "givenName": account_data.givenName
                },
                "password": account_data.password,
                "primaryEmail": account_data.primaryEmail,
                "changePasswordAtNextLogin": true
            }
        };

        return  await this.apiCall("users.insert", body);

    }


};