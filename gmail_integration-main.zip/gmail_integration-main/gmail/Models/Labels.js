"use strict";
const Abstract = require('./Abstract');

module.exports = class Labels extends Abstract {

    constructor(settings) {
        super(settings);
        this.responsePropertyName = "cfo-labels";
    }

    async create(name, background_colour, text_colour) {

        if(!name || !background_colour || !text_colour){
            return false;
        }

        let body = this.initBody();

        body.resource = {
            "labelListVisibility": "labelShow",
            "messageListVisibility": "show",
            "name": name,
            "color" : {
                "backgroundColor": background_colour,
                "textColor": text_colour
            }
        };

        let response = await this.apiCall("users.labels.create", body);
        if(response.id){
            return response.id;
        }
        else{
            return false;
        }
    }

    async delete(label_id) {

        if(!label_id){
            return false;
        }

        let body = this.initBody();

        body.id = label_id;

        return await this.apiCall("users.labels.delete", body);
    }

    async list(){

        let body = this.initBody();

        let response = await this.apiCall("users.labels.list", body);
        if(response.labels){
            return response.labels;
        }
        else{
            return false;
        }
    }
};