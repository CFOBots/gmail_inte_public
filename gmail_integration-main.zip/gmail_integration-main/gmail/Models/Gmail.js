"use strict";
const Abstract = require('./Abstract');

module.exports = class Gmail extends Abstract {

    constructor(settings) {
        super(settings);
    }

    getAuthUrl(scope) {
        return {
            redirect: {
                url: this.authClient.generateAuthUrl({
                    access_type: 'offline',
                    scope: scope,
                    prompt: "consent"
                })
            }
        };
    }


    async getAuthToken(code) {
        try{
            if(!code){
                return false;
            }
            let token = await this.authClient.getToken(code);
            return token.tokens;
        }
        catch(err){
            console.log(err);
        }
    }

};