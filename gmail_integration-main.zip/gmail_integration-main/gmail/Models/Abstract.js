"use strict";
const util = require('util');

module.exports = class Abstract {

    constructor(settings) {
        this.entityApiInstance = settings.apiService;
        this.authClient = settings.authClient;

        this.responseData = {};
        this.withPageNextTokenFlag = false;
    }

    setData(data) {
        for (let i in data) {
            this[i] = data[i];
        }
    }

    async apiCall(endpointName, endpointParameters) {

        let pageNextTokenFlag = true;

        try {

            let res = util.promisify(this.resolve(endpointName, this.entityApiInstance));

            do {

                let apiResponse = await res.bind(this.entityApiInstance)(endpointParameters);

                this.responseData = this.mergeResults(this.responseData, apiResponse.data);

                if(apiResponse.data && apiResponse.data.nextPageToken){
                    endpointParameters.pageToken = apiResponse.data.nextPageToken;
                }else{
                    pageNextTokenFlag = false;
                }
            }
            while (pageNextTokenFlag);

            return this.responseData;

        } catch (e) {

            let error = e.errors ? JSON.stringify(e.errors) : e;

            console.log(`The gmail call api fails doing the endpoint [ ${endpointName} ] with the params ${JSON.stringify(endpointParameters)} , the error message was: ${error}`);

            throw e;
            // return false;
        }
    }

    initBody() {
        return {'userId': 'me'}
    }

    resolve(path, obj) {

        return path.split('.').reduce(function (prev, curr) {
            return prev ? prev[curr] : null
        }, obj || self)
    }

    mergeResults(collectedData, apiResponseData){

        if(this.responsePropertyName){

            let mergeData;

            if(collectedData[this.responsePropertyName]){
                mergeData = { [this.responsePropertyName] : [ ...collectedData[this.responsePropertyName] , ...apiResponseData[this.responsePropertyName]]};
            }else{
                mergeData = apiResponseData;
            }

            return mergeData;
        }

        return Object.assign(collectedData , apiResponseData);
    }
};