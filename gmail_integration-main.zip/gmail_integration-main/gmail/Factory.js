"use strict";
const { google } = require('googleapis');

module.exports = class Factory {
    constructor (credentials){

        this.is_admin = credentials && credentials.is_admin == 'admin' ? 'admin' : 'user';

        this.authClient = new google.auth.OAuth2(
            credentials.client_id,
            credentials.secret,
            credentials.redirect_uris
        );

        let refresh_token_function = credentials.refresh_token_function ? credentials.refresh_token_function : (tokens) => {};

        this.authClient.on('tokens', (tokens) => {
            refresh_token_function(tokens, this);
        });
    }

    getEntity (entityType, token = undefined, data=undefined) {

        if (token) {
            this.setCredentials(token);
        }

        try {
            let apiService;

            if(this.is_admin == "admin"){
                apiService = google.admin({version: 'directory_v1', auth: this.authClient});
            }
            else if(this.is_admin == "user"){
                apiService = google.gmail({version: 'v1', auth: this.authClient});
            }
            // let apiService = google.gmail({version: 'v1', auth: this.authClient});

            let entityClass = require('./Models/'+ entityType.charAt(0).toUpperCase() + entityType.slice(1));

            let entity = new entityClass({apiService: apiService, authClient: this.authClient});

            if(data)
                entity.setData(data);

            return entity;
            
        } catch (e) {

            console.log(`The Gmail Integration Module failed trying to get the entity ${entityType}! Error: ${e.message}`);
            return false;
        }
    };

    setCredentials(token) {
        this.authClient.setCredentials(token);
    }
};

