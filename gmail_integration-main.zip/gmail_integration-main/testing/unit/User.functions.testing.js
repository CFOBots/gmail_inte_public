const User = require('../../gmail/Models/User');
let authClient = {"dummy": "dummy_object"};
let apiService = {"dummy": "dummy_service"};
let user = new User({apiService: apiService, authClient: authClient});


module.exports = {
    watchEmailWithoutParams: async () => {
        expect(await user.watchEmail()).toBeFalsy();
    },
    watchEmailWithTopicName: async () => {
        jest.spyOn(user, "apiCall").mockImplementation(() => {
            return {
                "historyId": "111029",
                "expiration": "102309"
            }

        });

        expect(await user.watchEmail("TopicName")).toEqual({
            "historyId": "111029",
            "expiration": "102309"
        });
    },

    stopWatchWithoutParams: async () => {
        expect(await user.stopWatch()).toBeFalsy();
    },
    stopWatchWithTopicName: async () => {
        jest.spyOn(user, "apiCall").mockImplementation(() => {
            return {}

        });

        expect(await user.stopWatch("TopicName")).toEqual({});
    },

};