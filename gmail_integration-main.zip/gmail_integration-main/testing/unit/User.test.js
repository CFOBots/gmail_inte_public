const userTestingFunctions = require('./User.functions.testing');

describe("Gmail Integration - Email Entity Class", () => {

    describe("watchEmail Method", () => {

        it('Called without topic name should return false', () => userTestingFunctions.watchEmailWithoutParams());

        it('Called with topic name should return an object with a historyId', () => userTestingFunctions.watchEmailWithTopicName());

    });

    describe("stopWatch Method", () => {

        it('Called without topic name should return false', () => userTestingFunctions.stopWatchWithoutParams());

        it('Called with topic name should return an empty object', () => userTestingFunctions.stopWatchWithTopicName());

    });

});
