const emailTestingFunctions = require('./Email.functions.testing');

describe("Gmail Integration - Email Entity Class", () => {

    describe("getMessage Method", () => {

        it('Called without message_id set should return false', () => emailTestingFunctions.getMessageWithoutMesageId());

        it('Called with message_id should return the user gmail message associated to that message_id', () => emailTestingFunctions.getMessageWithMessageId());

        it('Called with non existing message_id should return false', () => emailTestingFunctions.getMessageWithNonExistingMessageId());

    });

    describe("addLabel Method", () => {

        it('Called without message_id set should return false', () => emailTestingFunctions.addLabelWithoutMesageId());

        it('Called without params should return false', () => emailTestingFunctions.addLabelWithoutParams());

        it('Called with message_id and an existing label_id should return true', () => emailTestingFunctions.addLabelWithMessageIdAndCorrectLabelId());

        it('Called with message_id and a non existing label_id should return false', () => emailTestingFunctions.addLabelWithMessageIdAndIncorrectLabelId());

        it('Called with an non existing message_id should return false', () => emailTestingFunctions.addLabelWithNonExistingMessageId());

    });

    describe("removeLabel Method", () => {

        it('Called without message_id set should return false', () => emailTestingFunctions.removeLabelWithoutMesageId());

        it('Called without params should return false', () => emailTestingFunctions.removeLabelWithoutParams());

        it('Called with message_id and an existing label_id should return true', () => emailTestingFunctions.removeLabelWithMessageIdAndCorrectLabelId());

        it('Called with message_id and a non existing label_id should return false', () => emailTestingFunctions.removeLabelWithMessageIdAndIncorrectLabelId());

        it('Called with an non existing message_id should return false', () => emailTestingFunctions.removeLabelWithNonExistingMessageId());

    });

    describe("replaceLabel Method", () => {

        it('Called without message_id set should return false', () => emailTestingFunctions.replaceLabelWithoutMesageId());

        it('Called without params should return false', () => emailTestingFunctions.replaceLabelWithoutParams());

        it('Called with message_id and existing label_ids should return true', () => emailTestingFunctions.replaceLabelWithMessageIdAndCorrectLabelId());

        it('Called with message_id and a non existing label_ids should return false', () => emailTestingFunctions.replaceLabelWithMessageIdAndIncorrectLabelId());

        it('Called with an non existing message_id should return false', () => emailTestingFunctions.replaceLabelWithNonExistingMessageId());

    });

    describe("getAttachment Method", () => {

        it('Called without params should return false', () => emailTestingFunctions.getAttachmentWithoutParams());

        it('Called with a non existing attachment id should return false', () => emailTestingFunctions.getAttachmentWithNonExistingAttachId());

        it('Called with an existing attachment id should return the attachment', () => emailTestingFunctions.getAttachmentWithExistingAttachId());


    });

    describe("getAttachments Method", () => {

        it('Called without params should return false', () => emailTestingFunctions.getAttachmentsWithoutParams());

        it('Called with a message without payload parts should return false', () => emailTestingFunctions.getAttachmentsWithMessageWithNoPayloadParts());

        it('Called with a message with payload parts should return the attachments data', () => emailTestingFunctions.getAttachmentsWithMessageWithPayloadParts());

    });



});
