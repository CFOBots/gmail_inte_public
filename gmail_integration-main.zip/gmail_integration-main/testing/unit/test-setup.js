// const MysqlConnection = require('./../../db/MysqlConnection');
//
// global.connection = MysqlConnection.createConnection();
