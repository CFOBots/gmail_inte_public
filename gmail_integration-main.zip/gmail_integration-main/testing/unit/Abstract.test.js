const GmailAbstractClass = require("./../../gmail/Models/Abstract");

const gmailAbstractClass = new GmailAbstractClass({
    "scope": "Dummy",
    "client_id": "Dummy",
    "secret": "Dummy",
    "redirect_uris": "Dummy"
});

describe("Abstract Class", () => {

    describe("setData Method", () => {

        it('Called with object should set the key and value as class variable', async () => {
            await gmailAbstractClass.setData({"messageId" : "messageIdDummy"});
            expect(gmailAbstractClass.messageId).toBe("messageIdDummy");
        });

        // it('Called with an not existing model should return false', async () => {
        //     const response = await gmailAbstractClass.getEntity("dummy");
        //     expect(response).toBeFalsy();
        // });
        //
        // it('Called with an existing model should return the class', async () => {
        //     const response = await gmailAbstractClass.getEntity("history");
        //     expect(response).not.toBeFalsy();
        // });
    });

    describe("apiCall Method", () => {

        it('Called with object should set the key and value as class variable', async () => {
            await gmailAbstractClass.setData({"messageId" : "messageIdDummy"});
            expect(gmailAbstractClass.messageId).toBe("messageIdDummy");
        });
    });

    describe("mergeResults Method", () => {
        const responsePropertyName = "history";

        it('Called with no collected data and without api data', async () => {
            const response = await gmailAbstractClass.mergeResults({} , {});
            expect(response).toEqual({});
        });


        it('Called with no collected data and new api data but without the list property name',async () => {
            const response = await gmailAbstractClass.mergeResults({} , {"messageId" : "dummy"});
            expect(response.messageId).toBe("dummy");
        });

        it('Called with collected data and new api data but without the list property name',async () => {
            const response = await gmailAbstractClass.mergeResults({ "user" : "me" } , {"messageId" : "dummy"});
            expect(response).toEqual({ "user" : "me" , "messageId" : "dummy" });
        });

        it('Called without collected data and new api data but with the list property name' , async () => {
            gmailAbstractClass.setData({responsePropertyName : responsePropertyName});

            const response = await gmailAbstractClass.mergeResults({} , {
                [responsePropertyName]: [
                    {id: '335831', messages: [Array]},
                    {id: '335832', messages: [Array]},
                    {id: '335833', messages: [Array]}
                    ]
            });
            expect(response.history.length).toBe(3);
        });

        it('Called with collected data and new api data with the list correct property name', async () => {

            gmailAbstractClass.setData({responsePropertyName : responsePropertyName});

            const response1 = await gmailAbstractClass.mergeResults({} , {
                [responsePropertyName]: [
                    {id: '335831', messages: [Array]},
                    {id: '335832', messages: [Array]},
                    {id: '335833', messages: [Array]}
                ]
            });

            const response2 = await gmailAbstractClass.mergeResults(response1 , {
                [responsePropertyName]: [
                    {id: '335834', messages: [Array]},
                    {id: '335835', messages: [Array]},
                    {id: '335836', messages: [Array]},
                    {id: '335837', messages: [Array]},
                    {id: '335838', messages: [Array]},
                ]
            });
            expect(response2[responsePropertyName].length).toBe(8);
        });

        it('Called with collected data and without api data with the list correct property name', async () => {
            gmailAbstractClass.setData({responsePropertyName : responsePropertyName});

            const response =await gmailAbstractClass.mergeResults({
                [responsePropertyName]: [
                    {id: '335831', messages: [Array]},
                    {id: '335832', messages: [Array]},
                    {id: '335833', messages: [Array]}
                ]
            } , {[responsePropertyName]: []});
            expect(response[responsePropertyName].length).toBe(3);
        });

    });

});