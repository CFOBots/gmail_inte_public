const labelsTestingFunctions = require('./Labels.functions.testing');

describe("Gmail Integration - Email Entity Class", () => {

    describe("create Method", () => {

        it('Called without label_name should return false', () => labelsTestingFunctions.createWithoutParams());

        it('Called with name should return the label_id if the label_name does not exists', () => labelsTestingFunctions.createWithLabelName());

    });

    describe("list Method", () => {

        it('Called should return an array of Gmail Labels', () => labelsTestingFunctions.list());

    });

    // describe("delete Method", () => {
    //
    //     it('Called without label_id should return false', () => labelsTestingFunctions.deleteWithoutParams());
    //
    //     it('Called with non existing label_id should return an error', () => labelsTestingFunctions.deleteWithNonExistingLabelId());
    //
    //     it('Called with existing label_id should return ', () => labelsTestingFunctions.deleteWithExistingLabelId());
    //
    // });

});
