const GmailFactory = require("./../../gmail/Factory");
const gmailFactory = new GmailFactory({
    "scope": "Dummy",
    "client_id": "Dummy",
    "secret": "Dummy",
    "redirect_uris": "Dummy"
});

describe("Factory Class", () => {

    describe("getEntity Method", () => {

        it('Called without any param should return false', async () => {
            const response = await gmailFactory.getEntity();
            expect(response).toBeFalsy();
        });

        it('Called with an not existing model should return false', async () => {
            const response = await gmailFactory.getEntity("dummy");
            expect(response).toBeFalsy();
        });

        it('Called with an existing model should return the class', async () => {
            const response = await gmailFactory.getEntity("history");
            expect(response).not.toBeFalsy();
        });
    });
});