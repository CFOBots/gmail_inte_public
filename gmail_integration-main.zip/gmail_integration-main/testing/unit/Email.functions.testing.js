const Email = require('../../gmail/Models/Email');
let authClient = {"dummy": "dummy_object"};
let apiService = {"dummy": "dummy_service"};
let email = new Email({apiService: apiService, authClient: authClient});


module.exports = {
    getMessageWithoutMesageId: async () => expect(await email.getMessage()).toBeFalsy(),
    getMessageWithMessageId: async () => {
        jest.spyOn(email, "apiCall").mockImplementation(() => {
            return {
                "id": "16e897874008aff9",
                "payload": {
                    "headers": [
                        {
                            "name": "From",
                            "value": "Test Value"
                        }
                    ],
                    "parts": [
                        {
                            "filename": "Test 1",
                            "body": {
                                "attachmentId": "1",
                            }
                        },
                        {
                            "filename": "Test 2",
                            "body": {
                                "attachmentId": "2"
                            }
                        },
                        {
                            "filename": "Test 3",
                            "body": {
                                "attachmentId": "3"
                            }
                        }
                    ]
                }
            }
        });
        await email.setData({"message_id": "16e897874008aff9"});
        expect(await email.getMessage()).toEqual({
            "id": "16e897874008aff9",
            "payload": {
                "headers": [
                    {
                        "name": "From",
                        "value": "Test Value"
                    }
                ],
                "parts": [
                    {
                        "filename": "Test 1",
                        "body": {
                            "attachmentId": "1",
                        }
                    },
                    {
                        "filename": "Test 2",
                        "body": {
                            "attachmentId": "2"
                        }
                    },
                    {
                        "filename": "Test 3",
                        "body": {
                            "attachmentId": "3"
                        }
                    }
                ]
            }
        });
    },
    getMessageWithNonExistingMessageId: async () => {
        jest.spyOn(email, "apiCall").mockImplementation(() => {
            return {
                "error": {
                    "errors": [
                        {
                            "domain": "global",
                            "reason": "invalidArgument",
                            "message": "Invalid id value"
                        }
                    ],
                    "code": 400,
                    "message": "Invalid id value"
                }
            }
        });
        await email.setData({"message_id": "NonExistingMessageId"});
        expect(await email.getMessage()).toBeFalsy();
    },
    addLabelWithoutMesageId: async () => expect(await email.addLabel("Label_8")).toBeFalsy(),
    addLabelWithoutParams: async () => expect(await email.addLabel()).toBeFalsy(),
    addLabelWithMessageIdAndCorrectLabelId: async () => {

        jest.spyOn(email, "modify").mockImplementation(() => {
            return {
                "id": "16eb904f21d9879c",
                "threadId": "16eb904f21d9879c",
                "labelIds": [
                    "UNREAD",
                    "IMPORTANT",
                    "Label_8",
                    "CATEGORY_PERSONAL",
                    "INBOX"
                ]
            }
        });
        await email.setData({"message_id": "16eb904f21d9879c"});
        expect(await email.addLabel("Label_8")).toBeTruthy()
    },
    addLabelWithMessageIdAndIncorrectLabelId: async () => {

        jest.spyOn(email, "modify").mockImplementation(() => {
            return {
                "error": {
                    "errors": [
                        {
                            "domain": "global",
                            "reason": "invalidArgument",
                            "message": "labelId not found"
                        }
                    ],
                    "code": 400,
                    "message": "labelId not found"
                }
            }
        });
        await email.setData({"message_id": "16eb904f21d9879c"});
        expect(await email.addLabel("NonExistingLabel")).toBeFalsy()
    },
    addLabelWithNonExistingMessageId: async () => {

        jest.spyOn(email, "modify").mockImplementation(() => {
            return {
                "error": {
                    "errors": [
                        {
                            "domain": "global",
                            "reason": "invalidArgument",
                            "message": "Invalid id value"
                        }
                    ],
                    "code": 400,
                    "message": "Invalid id value"
                }
            }
        });
        await email.setData({"message_id": "16eb904f21d9879c"});
        expect(await email.addLabel("ExistingLabel")).toBeFalsy()
    },
    removeLabelWithoutMesageId: async () => expect(await email.removeLabel("Label_8")).toBeFalsy(),
    removeLabelWithoutParams: async () => expect(await email.removeLabel()).toBeFalsy(),
    removeLabelWithMessageIdAndCorrectLabelId: async () => {

        jest.spyOn(email, "modify").mockImplementation(() => {
            return {
                "id": "16eb904f21d9879c",
                "threadId": "16eb904f21d9879c",
                "labelIds": [
                    "UNREAD",
                    "IMPORTANT",
                    "CATEGORY_PERSONAL",
                    "INBOX"
                ]
            }
        });
        await email.setData({"message_id": "16eb904f21d9879c"});
        expect(await email.removeLabel("Label_8")).toBeTruthy()
    },
    removeLabelWithMessageIdAndIncorrectLabelId: async () => {

        jest.spyOn(email, "modify").mockImplementation(() => {
            return {
                "error": {
                    "errors": [
                        {
                            "domain": "global",
                            "reason": "invalidArgument",
                            "message": "labelId not found"
                        }
                    ],
                    "code": 400,
                    "message": "labelId not found"
                }
            }
        });
        await email.setData({"message_id": "16eb904f21d9879c"});
        expect(await email.removeLabel("NonExistingLabel")).toBeFalsy()
    },
    removeLabelWithNonExistingMessageId: async () => {

        jest.spyOn(email, "modify").mockImplementation(() => {
            return {
                "error": {
                    "errors": [
                        {
                            "domain": "global",
                            "reason": "invalidArgument",
                            "message": "Invalid id value"
                        }
                    ],
                    "code": 400,
                    "message": "Invalid id value"
                }
            }
        });
        await email.setData({"message_id": "16eb904f21d9879c"});
        expect(await email.removeLabel("ExistingLabel")).toBeFalsy()
    },
    replaceLabelWithoutMesageId: async () => expect(await email.replaceLabel("add_id", "remove_id")).toBeFalsy(),
    replaceLabelWithoutParams: async () => expect(await email.replaceLabel()).toBeFalsy(),
    replaceLabelWithMessageIdAndCorrectLabelId: async () => {

        jest.spyOn(email, "modify").mockImplementation(() => {
            return {
                "id": "16eb904f21d9879c",
                "threadId": "16eb904f21d9879c",
                "labelIds": [
                    "UNREAD",
                    "IMPORTANT",
                    "add_id",
                    "CATEGORY_PERSONAL",
                    "INBOX"
                ]
            }
        });
        await email.setData({"message_id": "16eb904f21d9879c"});
        expect(await email.replaceLabel("add_id", "remove_id")).toBeTruthy()
    },
    replaceLabelWithMessageIdAndIncorrectLabelId: async () => {

        jest.spyOn(email, "modify").mockImplementation(() => {
            return {
                "error": {
                    "errors": [
                        {
                            "domain": "global",
                            "reason": "invalidArgument",
                            "message": "labelId not found"
                        }
                    ],
                    "code": 400,
                    "message": "labelId not found"
                }
            }
        });
        await email.setData({"message_id": "16eb904f21d9879c"});
        expect(await email.replaceLabel("NonExistingLabel", "ExistingLabel")).toBeFalsy()
    },
    replaceLabelWithNonExistingMessageId: async () => {

        jest.spyOn(email, "modify").mockImplementation(() => {
            return {
                "error": {
                    "errors": [
                        {
                            "domain": "global",
                            "reason": "invalidArgument",
                            "message": "Invalid id value"
                        }
                    ],
                    "code": 400,
                    "message": "Invalid id value"
                }
            }
        });
        await email.setData({"message_id": "NonExistingMessageId"});
        expect(await email.replaceLabel("ExistingLabel", "ExistingLabel")).toBeFalsy()
    },
    getAttachmentWithoutParams: async () => {
        expect(await email.getAttachment()).toBeFalsy()
    },
    getAttachmentWithNonExistingAttachId: async () => {
        jest.spyOn(email, "apiCall").mockImplementation(() => {
            return {
                "error": {
                    "errors": [
                        {
                            "domain": "global",
                            "reason": "invalidArgument",
                            "message": "Invalid attachment token"
                        }
                    ],
                    "code": 400,
                    "message": "Invalid attachment token"
                }
            }
        });
        expect(await email.getAttachment("Non_existing_attach_id")).toBeFalsy()
    },
    getAttachmentWithExistingAttachId: async () => {
        jest.spyOn(email, "apiCall").mockImplementation(() => {
            return {
                "data": {
                    "size": 878121,
                    "data": "fileDataBase64"
                }
            }
        });
        expect(await email.getAttachment("ExistingAttachId")).toEqual({
            "size": 878121,
            "data": "fileDataBase64"
        })
    },
    getAttachmentsWithoutParams: async () => {
        expect(await email.getAttachments()).toBeFalsy()
    },
    getAttachmentsWithMessageWithNoPayloadParts: async () => {
        expect(await email.getAttachments({payload: {no_parts: []}})).toBeFalsy()
    },
    getAttachmentsWithMessageWithPayloadParts: async () => {
        jest.spyOn(email, "getAttachment").mockImplementation(() => {
            return {data: "fileDataBase64", size: 878121}
        });
        expect(await email.getAttachments({
            payload: {
                parts: [{
                    "partId": "1",
                    "filename": "File name test",
                    "body": {
                        "attachmentId": "attachmentId1234",
                        "size": 878121
                    }
                }]
            }
        })).toEqual({"File name test": {"data": "fileDataBase64", "size":878121}})
    },

};