const Labels = require('../../gmail/Models/Labels');
let authClient = {"dummy": "dummy_object"};
let apiService = {"dummy": "dummy_service"};
let labels = new Labels({apiService: apiService, authClient: authClient});


module.exports = {
    createWithoutParams: async () => {
        expect(await labels.create()).toBeFalsy();
    },
    createWithLabelName: async () => {
        jest.spyOn(labels, "apiCall").mockImplementation(() => {
            return {
                "id": "Label_57",
                "name": "LABEL-NAME",
                "messageListVisibility": "show",
                "labelListVisibility": "labelShow"
            }

        });

        expect(await labels.create("LABEL-NAME")).toBe("Label_57");
    },

    list: async () => {
        jest.spyOn(labels, "apiCall").mockImplementation(() => {
            return {labels:[{
                "id": "Label_57",
                "name": "LABEL-NAME",
                "messageListVisibility": "show",
                "labelListVisibility": "labelShow"
            }, {
                    "id": "Label_58",
                    "name": "LABEL-NAME2",
                    "messageListVisibility": "show",
                    "labelListVisibility": "labelShow"
                }]}

        });

        expect(await labels.list()).toEqual([{
            "id": "Label_57",
            "name": "LABEL-NAME",
            "messageListVisibility": "show",
            "labelListVisibility": "labelShow"
        }, {
            "id": "Label_58",
            "name": "LABEL-NAME2",
            "messageListVisibility": "show",
            "labelListVisibility": "labelShow"
        }]);
    },

    // deleteWithoutParams: async () => {
    //     expect(await labels.create()).toBeFalsy();
    // },
    // deleteWithNonExistingLabelId: async () => {
    //     jest.spyOn(labels, "apiCall").mockImplementation(() => {
    //         return {
    //             "error": {
    //                 "errors": [
    //                     {
    //                         "domain": "global",
    //                         "reason": "notFound",
    //                         "message": "Not Found"
    //                     }
    //                 ],
    //                 "code": 404,
    //                 "message": "Not Found"
    //             }
    //         }
    //
    //     });
    //
    //     expect(await labels.create("Non_Existing_Label_Id")).toEqual({
    //         "error": {
    //             "errors": [
    //                 {
    //                     "domain": "global",
    //                     "reason": "notFound",
    //                     "message": "Not Found"
    //                 }
    //             ],
    //             "code": 404,
    //             "message": "Not Found"
    //         }
    //     });
    // },

    // deleteWithExistingLabelId: async () => {
    //     jest.spyOn(labels, "apiCall").mockImplementation(() => {
    //         return {
    //             "error": {
    //                 "errors": [
    //                     {
    //                         "domain": "global",
    //                         "reason": "notFound",
    //                         "message": "Not Found"
    //                     }
    //                 ],
    //                 "code": 404,
    //                 "message": "Not Found"
    //             }
    //         }
    //
    //     });
    //
    //     expect(await labels.create("Non_Existing_Label_Id")).toEqual();
    // },

};